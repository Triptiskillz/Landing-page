# Landing Page Project
## The Band Blog life
### This is a topic of project . In the top of the page we add the **Navbar**,this is options given...

#### 1.HOME
#### 2.TOUR
#### 3.BAND
#### 4.CONTACT
#### 5.MORE
        1.Merchandise
        2.Extras
        3.Media
## SUBSCRIBE 
### when click subscribe Botton, a new file will be open and only enter the email and always get new information about the blog.

<!--image-->
![image](https://static.standard.co.uk/s3fs-public/thumbnails/image/2018/12/28/08/danny-howe-762860.jpg)
![image](https://assets.wallpapersin4k.org/uploads/2017/04/Dj-Night-Wallpaper-15.jpg)
![image](https://i.ytimg.com/vi/WbkRrpxKwcI/maxresdefault.jpg)
### This image is where has done performance, this image sequence change after per 4 seconds .
## THE BAND
### Here ,we share the information about the **Member Of Band** and **THE Band**(Like which type of music are perform etc.)
**Name of Member**
    ![image](https://mfiles.alphacoders.com/697/697803.jpg)
## TOUR DATES
### Here,share the information about recently where will go to perform (date,place) and purchase the ticket for the event when click the Buy Tickets button .A new file will open.
## CONTACT
### Here,share the information about the where live,phone number,email and also contact with the band only fill the form which in given the  blog.
    Name
    Email
    Message
 **If user like the page then click the Like Button and also share the page in the social media.** 

